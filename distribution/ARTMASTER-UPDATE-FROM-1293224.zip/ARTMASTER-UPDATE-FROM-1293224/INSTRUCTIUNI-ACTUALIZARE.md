# Actualizare ARTMASTER — numai de la versiunea 1293224

Acest pachet contine numai fisiere schimbate de auditul SEO/securitate. Nu este o instalare completa. Sursa si baza sunt in PACKAGE-INFO.json.

1. Opreste propria instanta cu Ctrl+C. Pastreaza o copie PRIVATA a folderului si verifica procedura de backup; nu distribui baza sau parolele.
2. Confirma versiunea de baza 129322483e2b9d6892913c9f5c0f2c380628f705. Daca ai o alta baza sau editari proprii, compara fisierele inainte de copiere; nu suprascrie automat.
3. Copiaza numai fisierele din acest folder peste copia compatibila. Pastreaza .data, .env.local, public/partners, src/lib/partners.ts si src/components/home.tsx. Acestea NU sunt incluse/modificate aici.
4. Nu sterge folderele cu date sau fisierele tale publice. SQLite adauga numai tabelul de diagnostic SEO la prima accesare, fara rescrierea mesajelor, continutului sau imaginilor.
5. Ruleaza START.bat. Foloseste conturile existente. Nu crea un cont cu o parola demonstrativa. Pentru instalare noua foloseste arhiva COMPLETA intr-un folder nou si CREATE-ADMIN.bat cu parola proprie.
6. Verifica site-ul, formularele sintetice -> CRM, draft/preview/publish si SEO la /admin#seo. Nu aplica migrari Supabase pe productie. Revizuirea si staging sunt obligatorii.

Node 24+ este necesar. Windows nativ si Supabase/Google reale nu au fost validate. Nu face deploy/DNS si nu atinge Host.md prin acest pachet.
