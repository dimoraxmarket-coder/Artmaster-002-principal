import { z } from "zod";
import type { SiteContent } from "../content/types";

const text = (max: number) => z.string().trim().min(1).max(max);
const localized = z
  .object({ ro: text(12000), ru: text(12000), en: text(12000) })
  .strict();
const slug = z
  .string()
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/)
  .max(100);
const image = z
  .string()
  .max(500)
  .refine((value) => {
    if (
      /^\/(?:images|media|api\/media)\/[a-zA-Z0-9/_-]+\.(?:webp|png|jpg|jpeg|avif|svg)$/.test(
        value,
      )
    )
      return true;
    try {
      const url = new URL(value),
        configured = new URL(
          process.env.SUPABASE_URL || "https://unconfigured.invalid",
        );
      return (
        url.protocol === "https:" &&
        !url.username &&
        !url.password &&
        url.origin === configured.origin &&
        /^\/storage\/v1\/object\/public\/portfolio\/[a-f0-9-]{36}\.webp$/.test(
          url.pathname,
        ) &&
        !url.search &&
        !url.hash
      );
    } catch {
      return false;
    }
  });
const httpsUrl = z
  .string()
  .max(500)
  .refine((value) => {
    try {
      const url = new URL(value);
      return (
        url.protocol === "https:" &&
        !url.username &&
        !url.password &&
        !url.search &&
        !url.hash
      );
    } catch {
      return false;
    }
  });
const bannerAsset = z
  .object({
    image,
    width: z.number().int().min(1).max(30000),
    height: z.number().int().min(1).max(30000),
    alt: localized,
  })
  .strict();
const managedPartner = z
  .object({
    slug,
    name: text(150),
    image: image.optional(),
    alt: localized,
    website: httpsUrl.optional(),
    sourceUrl: httpsUrl.optional(),
    provenance: z.string().trim().max(2000),
    identity: z.enum(["unconfirmed", "confirmed"]),
    relationshipConfirmed: z.boolean(),
    rights: z.enum(["unverified", "owner-authorized", "official-permission"]),
    status: z.enum(["draft", "published", "hidden", "archived"]),
  })
  .strict();
const refs = z.array(slug).max(30);
const localizedList = z
  .object({
    ro: z.array(text(1000)).max(30),
    ru: z.array(text(1000)).max(30),
    en: z.array(text(1000)).max(30),
  })
  .strict();
const faq = z.object({ question: localized, answer: localized }).strict();
const base = { slug, title: localized, summary: localized };
const sourceUrl = z.union([
  z.literal(""),
  z
    .url()
    .max(1000)
    .refine((value) => {
      const u = new URL(value);
      return u.protocol === "https:" && !u.username && !u.password;
    }),
]);
const heroAsset = z
  .object({
    image,
    video: z
      .string()
      .regex(/^\/api\/media\/[a-f0-9-]{36}\.(mp4|webm)$/)
      .optional(),
  })
  .strict();
const equipmentCatalog = z
  .object({
    model: text(150),
    manufacturer: z.string().trim().max(150),
    category: localized,
    verification: z.enum([
      "unverified",
      "manufacturer_documented",
      "owner_confirmed",
    ]),
    sourceUrl,
    imageRights: z.enum(["pending", "owner", "licensed", "concept"]),
    licenseNote: z.string().trim().max(2000),
    order: z.number().int().min(0).max(10000),
    published: z.boolean(),
    specs: z
      .array(z.object({ label: localized, value: localized }).strict())
      .max(40),
  })
  .strict();
export const contentSchema: z.ZodType<SiteContent> = z
  .object({
    heroMedia: z
      .object({ desktop: heroAsset, mobile: heroAsset.optional() })
      .strict()
      .optional(),
    banner: z
      .object({
        enabled: z.boolean(),
        desktop: bannerAsset,
        mobile: bannerAsset.optional(),
      })
      .strict()
      .optional(),
    partners: z.array(managedPartner).max(100).optional(),
    copy: z
      .object({
        hero: z
          .object({
            eyebrow: localized,
            title: localized,
            accent: localized,
            description: localized,
            quoteLabel: localized,
            servicesLabel: localized,
          })
          .strict(),
        about: z
          .object({
            title: localized,
            summary: localized,
            heading: localized,
            body: localized,
            approach: localized,
            equipmentHeading: localized,
          })
          .strict(),
      })
      .strict()
      .optional(),
    services: z
      .array(
        z
          .object({
            ...base,
            description: localized,
            applications: localizedList,
            quoteHints: localizedList,
            faqs: z.array(faq).max(20),
            image,
            relatedSlugs: refs,
            equipmentSlugs: refs,
          })
          .strict(),
      )
      .min(1)
      .max(40),
    equipment: z
      .array(
        z
          .object({
            ...base,
            description: localized,
            image,
            serviceSlugs: refs,
            facts: z.array(localized).max(30),
            catalog: equipmentCatalog.optional(),
          })
          .strict(),
      )
      .max(60),
    projects: z
      .array(
        z
          .object({
            ...base,
            description: localized,
            image,
            serviceSlugs: refs,
            kind: z.enum(["concept", "real"]),
            published: z.boolean(),
          })
          .strict(),
      )
      .max(250),
    articles: z
      .array(
        z
          .object({
            ...base,
            paragraphs: localizedList,
            serviceSlugs: refs,
            published: z.boolean(),
          })
          .strict(),
      )
      .max(100),
    faqs: z.array(faq).max(40),
    contact: z
      .object({
        phone: z.string().regex(/^\+?[0-9 ()-]{7,25}$/),
        email: z.email().max(254),
        address: localized,
        whatsapp: z
          .string()
          .regex(/^\+?[0-9]{7,16}$/)
          .or(z.literal("")),
        areas: localized,
        companyName: text(120),
      })
      .strict(),
  })
  .strict()
  .superRefine((content, ctx) => {
    content.equipment.forEach((e, i) => {
      if (
        e.catalog?.published &&
        (e.catalog.verification !== "owner_confirmed" ||
          !["owner", "licensed"].includes(e.catalog.imageRights) ||
          !e.catalog.licenseNote.trim() ||
          (e.catalog.imageRights === "licensed" && !e.catalog.sourceUrl))
      )
        ctx.addIssue({
          code: "custom",
          path: ["equipment", i, "catalog"],
          message:
            "Confirm the workshop model and image rights before publication",
        });
    });
    const partnerIds = new Set<string>();
    const partnerNames = new Set<string>();
    (content.partners || []).forEach((p, i) => {
      if (partnerIds.has(p.slug))
        ctx.addIssue({
          code: "custom",
          path: ["partners", i, "slug"],
          message: "Duplicate partner",
        });
      partnerIds.add(p.slug);
      const normalizedName = p.name.normalize("NFKC").toLocaleLowerCase();
      if (partnerNames.has(normalizedName))
        ctx.addIssue({
          code: "custom",
          path: ["partners", i, "name"],
          message: "Duplicate partner name",
        });
      partnerNames.add(normalizedName);
      if (
        p.status === "published" &&
        (p.identity !== "confirmed" || !p.relationshipConfirmed)
      )
        ctx.addIssue({
          code: "custom",
          path: ["partners", i, "status"],
          message: "Confirm identity and relationship before publication",
        });
      if (
        p.image &&
        p.status === "published" &&
        (p.rights === "unverified" ||
          !p.provenance.trim() ||
          (p.rights === "official-permission" && !p.sourceUrl))
      )
        ctx.addIssue({
          code: "custom",
          path: ["partners", i, "rights"],
          message: "Confirm logo permission and provenance before publication",
        });
    });
    for (const key of [
      "services",
      "equipment",
      "projects",
      "articles",
    ] as const) {
      const seen = new Set<string>();
      content[key].forEach((entry, i) => {
        if (seen.has(entry.slug))
          ctx.addIssue({
            code: "custom",
            path: [key, i, "slug"],
            message: "Duplicate slug",
          });
        seen.add(entry.slug);
      });
    }
    const services = new Set(content.services.map((s) => s.slug)),
      equipment = new Set(content.equipment.map((e) => e.slug));
    content.services.forEach((s, i) => {
      if (
        s.relatedSlugs.some((x) => !services.has(x)) ||
        s.equipmentSlugs.some((x) => !equipment.has(x))
      )
        ctx.addIssue({
          code: "custom",
          path: ["services", i],
          message: "Unknown reference",
        });
    });
    for (const key of ["equipment", "projects", "articles"] as const)
      content[key].forEach((entry, i) => {
        if (entry.serviceSlugs.some((x) => !services.has(x)))
          ctx.addIssue({
            code: "custom",
            path: [key, i, "serviceSlugs"],
            message: "Unknown reference",
          });
      });
  });

export const quoteSchema = z
  .object({
    locale: z.enum(["ro", "ru", "en"]),
    service: z.string().min(1).max(100),
    name: text(100),
    email: z
      .email()
      .max(254)
      .transform((v) => v.toLowerCase()),
    phone: z
      .string()
      .trim()
      .max(30)
      .regex(/^[+0-9 ()-]{6,30}$/),
    message: text(5000),
    consent: z.literal("true"),
    website: z.literal(""),
    company: z.string().trim().max(150).default(""),
    dimensions: z.string().trim().max(200).default(""),
    quantity: z
      .string()
      .regex(/^(?:|[1-9]\d{0,6})$/)
      .default(""),
    deadline: z
      .string()
      .refine(
        (value) =>
          value === "" ||
          (/^\d{4}-\d{2}-\d{2}$/.test(value) &&
            !Number.isNaN(Date.parse(value)) &&
            new Date(value).toISOString().slice(0, 10) === value),
      )
      .default(""),
    sourcePath: z
      .string()
      .max(100)
      .regex(/^(?:|\/(?:ro|ru|en)(?:\/(?:contact|solicita-oferta))?\/?)$/)
      .default(""),
    token: z.string().min(20).max(2000),
    idempotencyKey: z.uuid(),
  })
  .strict();
export type QuoteInput = z.infer<typeof quoteSchema>;
export type QuoteStatus = "new" | "in_progress" | "completed" | "archived";
export const quoteStatusSchema = z.enum([
  "new",
  "in_progress",
  "completed",
  "archived",
]);
